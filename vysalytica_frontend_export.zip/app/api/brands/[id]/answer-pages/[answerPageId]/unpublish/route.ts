import { NextResponse } from 'next/server';
import { unpublishAnswerPage } from '@/lib/answerHub/service';

export async function POST(
    request: Request,
    { params }: { params: { id: string; answerPageId: string } }
) {
    try {
        const { id: brandId, answerPageId } = params;

        const updatedPage = await unpublishAnswerPage({
            brandId,
            answerPageId
        });

        return NextResponse.json({
            success: true,
            answerPage: updatedPage
        });
    } catch (error: any) {
        console.error('Error unpublishing answer page:', error);
        return new NextResponse(error.message, { status: 400 });
    }
}
